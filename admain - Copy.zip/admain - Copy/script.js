document.addEventListener("DOMContentLoaded", function() {
    console.log("Gawla Dashboard DOM Loaded");

    // Handle New Ticket Form Submit (Moved to top for reliability)
    const newTicketForm = document.getElementById('newTicketForm');
    if (newTicketForm) {
        newTicketForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log("New Ticket Form Submitted");
            
            const place = document.getElementById('newTicketPlace').value;
            const audienceEl = document.querySelector('input[name="newTicketAudience"]:checked');
            const typeEl = document.querySelector('input[name="newTicketType"]:checked');
            const price = document.getElementById('newTicketPrice').value;
            const currency = document.getElementById('newTicketCurrency').value;
            const statusEl = document.querySelector('input[name="newTicketStatus"]:checked');

            if (!place || !audienceEl || !typeEl || !statusEl) {
                alert("Please fill all required fields.");
                return;
            }

            const audience = audienceEl.value;
            const type = typeEl.value;
            const status = statusEl.value;

            // Generate ID
            const id = (Math.floor(Math.random() * 100) + 1).toString().padStart(2, '0');

            const newRow = document.createElement('tr');
            newRow.className = 'border-bottom ticket-row';
            newRow.innerHTML = `
                <td class="py-3 ps-4 fw-medium" style="color: #242448;">${id}</td>
                <td class="py-3 text-center fw-medium" style="color: #242448;">${place}</td>
                <td class="py-3 text-center fw-medium" style="color: #242448;">${audience}</td>
                <td class="py-3 text-center fw-medium" style="color: #242448;">${type}</td>
                <td class="py-3 text-center fw-medium" style="color: #242448;">${price} ${currency}</td>
                <td class="py-3 text-center">
                    <span class="badge status-badge ${status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary bg-opacity-10'} rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2" style="${status === 'Active' ? '' : 'color: #242448;'}">
                        <span class="rounded-circle ${status === 'Active' ? 'bg-success' : ''}" style="width: 6px; height: 6px; ${status === 'Active' ? '' : 'background-color: #242448;'}"></span> ${status}
                    </span>
                </td>
                <td class="py-3 text-end pe-4">
                    <i class="fas fa-pencil-alt cursor-pointer fs-5 me-3 edit-ticket-btn" style="color: #4a4a68;"></i>
                    <i class="fas fa-ban text-warning cursor-pointer fs-5 me-3 status-toggle-btn"></i>
                    <i class="far fa-trash-alt text-danger cursor-pointer fs-5 delete-btn" data-bs-toggle="modal" data-bs-target="#deleteTicketModal"></i>
                </td>
            `;

            const tbody = document.querySelector('#v-pills-tickets tbody');
            if (tbody) {
                tbody.prepend(newRow);
                console.log("Row added to table");
            } else {
                console.error("Tbody not found in #v-pills-tickets");
            }
            
            const modalEl = document.getElementById('newTicketModal');
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.hide();
            newTicketForm.reset();
        });
    }

    // Handle Edit Ticket Form Submit
    const editTicketForm = document.getElementById('editTicketForm');
    let currentRow = null;
    if (editTicketForm) {
        editTicketForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log("Edit Ticket Form Submitted");
            if (!currentRow) return;

            const place = document.getElementById('editTicketPlace').value;
            const audienceEl = document.querySelector('input[name="editTicketAudience"]:checked');
            const typeEl = document.querySelector('input[name="editTicketType"]:checked');
            const price = document.getElementById('editTicketPrice').value;
            const currency = document.getElementById('editTicketCurrency').value;
            const statusEl = document.querySelector('input[name="editTicketStatus"]:checked');

            if (!place || !audienceEl || !typeEl || !statusEl) {
                alert("Please fill all required fields.");
                return;
            }

            const audience = audienceEl.value;
            const type = typeEl.value;
            const status = statusEl.value;

            currentRow.cells[1].textContent = place;
            currentRow.cells[2].textContent = audience;
            currentRow.cells[3].textContent = type;
            currentRow.cells[4].textContent = `${price} ${currency}`;
            
            const badge = currentRow.querySelector('.status-badge');
            if (status === 'Active') {
                badge.className = 'badge status-badge bg-success-subtle text-success rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                badge.style.color = '';
                badge.innerHTML = '<span class="rounded-circle bg-success" style="width: 6px; height: 6px;"></span> Active';
            } else {
                badge.className = 'badge status-badge bg-secondary bg-opacity-10 rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                badge.style.color = '#242448';
                badge.innerHTML = '<span class="rounded-circle" style="width: 6px; height: 6px; background-color: #242448;"></span> Inactive';
            }

            const modalEl = document.getElementById('editTicketModal');
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.hide();
        });
    }

    // Ticket Actions (Edit, Status Toggle)
    document.addEventListener('click', function(e) {
        // Edit Ticket Button
        if (e.target.closest('.edit-ticket-btn')) {
            currentRow = e.target.closest('tr');
            console.log("Edit Ticket Clicked");
            
            const place = currentRow.cells[1].textContent.trim();
            const audience = currentRow.cells[2].textContent.trim();
            const type = currentRow.cells[3].textContent.trim();
            const priceText = currentRow.cells[4].textContent.trim();
            const badge = currentRow.querySelector('.status-badge');
            const status = badge ? badge.textContent.trim() : "";

            const [price, currency] = priceText.split(' ');

            document.getElementById('editTicketPlace').value = place;
            
            // Set radio buttons
            const audienceRadio = document.querySelector(`input[name="editTicketAudience"][value="${audience}"]`);
            if (audienceRadio) audienceRadio.checked = true;

            const typeRadio = document.querySelector(`input[name="editTicketType"][value="${type}"]`);
            if (typeRadio) typeRadio.checked = true;

            document.getElementById('editTicketPrice').value = price;
            document.getElementById('editTicketCurrency').value = currency;
            
            const normalizedStatus = status.includes('Active') ? 'Active' : 'Inactive';
            const statusRadio = document.querySelector(`input[name="editTicketStatus"][value="${normalizedStatus}"]`);
            if (statusRadio) statusRadio.checked = true;

            const modalEl = document.getElementById('editTicketModal');
            if (modalEl) {
                const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                modal.show();
            }
        }

        // Status Toggle (Ban Icon)
        if (e.target.closest('.status-toggle-btn') && e.target.closest('.ticket-row')) {
            const row = e.target.closest('tr');
            const badge = row.querySelector('.status-badge');
            if (!badge) return;
            const isCurrentlyActive = badge.textContent.trim().includes('Active');
            
            if (isCurrentlyActive) {
                badge.className = 'badge status-badge bg-secondary bg-opacity-10 rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                badge.style.color = '#242448';
                badge.innerHTML = '<span class="rounded-circle" style="width: 6px; height: 6px; background-color: #242448;"></span> Inactive';
            } else {
                badge.className = 'badge status-badge bg-success-subtle text-success rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                badge.style.color = '';
                badge.innerHTML = '<span class="rounded-circle bg-success" style="width: 6px; height: 6px;"></span> Active';
            }
        }
    });

    // Add row to table helper
    window.addTicketToTable = function(data) {
        const tbody = document.querySelector('#v-pills-tickets .table tbody');
        if (!tbody) return;

        const newRow = document.createElement('tr');
        newRow.className = 'border-bottom ticket-row';
        newRow.innerHTML = `
            <td class="py-3 ps-4 text-muted small fw-medium">New</td>
            <td class="py-3 fw-bold" style="color: #242448;">${data.place}</td>
            <td class="py-3 text-center fw-medium" style="color: #242448;">${data.audience}</td>
            <td class="py-3 text-center fw-medium" style="color: #242448;">${data.type}</td>
            <td class="py-3 text-center fw-bold text-dark">${data.price} ${data.currency}</td>
            <td class="py-3 text-center">
                <span class="badge status-badge ${data.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary bg-opacity-10'} rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2" ${data.status !== 'Active' ? 'style="color: #242448;"' : ''}>
                    <span class="rounded-circle ${data.status === 'Active' ? 'bg-success' : ''}" style="width: 6px; height: 6px; ${data.status !== 'Active' ? 'background-color: #242448;' : ''}"></span> ${data.status}
                </span>
            </td>
            <td class="py-3 text-end pe-4">
                <i class="fas fa-pencil-alt edit-ticket-btn cursor-pointer fs-5 me-3" style="color: #4a4a68;"></i>
                <i class="fas fa-ban status-toggle-btn cursor-pointer fs-5 me-3" style="color: #f59e0b;"></i>
                <i class="far fa-trash-alt delete-btn cursor-pointer fs-5 text-danger" data-bs-toggle="modal" data-bs-target="#deleteEventModal"></i>
            </td>
        `;
        tbody.prepend(newRow);
    };

    // 1. Line Chart (Bookings Over Time)
    const lineChartEl = document.getElementById('lineChart');
    if (lineChartEl) {
        const existingChart = Chart.getChart(lineChartEl);
        if (existingChart) existingChart.destroy();

        const lineCtx = lineChartEl.getContext('2d');
        const gradient = lineCtx.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, 'rgba(181, 155, 117, 0.2)');   
        gradient.addColorStop(1, 'rgba(181, 155, 117, 0)');

        new Chart(lineCtx, {
            type: 'line',
            data: {
                labels: ['JAN 10', 'FEB 20', 'MAR 30', 'APR 10', 'MAY 20', 'JUN 30', 'JUL 10', 'AUG 20', 'SEP 30', 'OCT 10', 'NOV 20', 'DEC 30'],
                datasets: [{
                    label: 'Bookings',
                    data: [30, 45, 35, 60, 40, 75, 45, 50, 70, 40, 65, 50],
                    borderColor: '#b59b75',
                    backgroundColor: gradient,
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#fff',
                        titleColor: '#333',
                        bodyColor: '#666',
                        borderColor: '#ddd',
                        borderWidth: 1,
                        padding: 10,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y + ' Bookings';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false, drawBorder: false },
                        ticks: { color: '#adb5bd', font: { size: 10 } }
                    },
                    y: { display: false, min: 0 }
                }
            }
        });
    }

    // 2. Bar Chart (Monthly Revenue)
    const barChartEl = document.getElementById('barChart');
    if (barChartEl) {
        const existingChart = Chart.getChart(barChartEl);
        if (existingChart) existingChart.destroy();

        const barCtx = barChartEl.getContext('2d');
    
    new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY'],
            datasets: [{
                label: 'Revenue',
                data: [30, 55, 95, 50, 65],
                backgroundColor: [
                    '#e9ecef', // Light gray
                    '#dcd8cd', // Tan
                    '#242448', // Navy highlight
                    '#e9ecef', 
                    '#dcd8cd'
                ],
                borderRadius: 0,
                barThickness: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + 'k EGP';
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        color: '#adb5bd',
                        font: {
                            size: 10
                        }
                    }
                },
                y: {
                    display: false, // Hide Y axis
                    min: 0
                }
            }
        }
    });
}

    // 3. User Growth Bar Chart (Users Tab)
    const userGrowthCanvas = document.getElementById('userGrowthChart');
    if (userGrowthCanvas) {
        const existingChart = Chart.getChart(userGrowthCanvas);
        if (existingChart) existingChart.destroy();

        const userGrowthCtx = userGrowthCanvas.getContext('2d');
        new Chart(userGrowthCtx, {
            type: 'bar',
            data: {
                labels: ['OCT', 'NOV', 'DEC', 'JAN', 'FEB'],
                datasets: [{
                    label: 'Users',
                    data: [150, 200, 180, 250, 320],
                    backgroundColor: [
                        '#e9ecef',
                        '#e9ecef',
                        '#e9ecef',
                        '#e9ecef',
                        '#b59b75' // Theme color for active bar
                    ],
                    borderRadius: 0,
                    barThickness: 75
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false,
                            drawBorder: false
                        },
                        ticks: {
                            color: '#adb5bd',
                            font: {
                                size: 10,
                                weight: 'bold'
                            }
                        }
                    },
                    y: {
                        display: false,
                        min: 0
                    }
                }
            }
        });
    }

    // 4. Pagination Logic for Users (Static HTML)
    const paginationContainer = document.getElementById('users-pagination');
    const paginationInfo = document.getElementById('pagination-info');
    const prevBtn = document.querySelector('.prev-page');
    const nextBtn = document.querySelector('.next-page');
    const userRows = document.querySelectorAll('.user-row');

    if (paginationContainer && paginationInfo) {
        // First 3 spans with class 'page-num' are the dynamic block
        const pageNumsNodes = paginationContainer.querySelectorAll('.page-num');
        const middlePageNums = Array.from(pageNumsNodes).slice(0, 3);
        const lastPageBtn = pageNumsNodes[3]; // The "248" span
        
        let currentBlockStart = 1;
        let currentPage = 1;
        const totalUsers = 2482;
        const itemsPerPage = 10;

        function updatePaginationUI() {
            // Update the 3 middle numbers
            middlePageNums.forEach((span, index) => {
                const pageNum = currentBlockStart + index;
                span.textContent = pageNum;
                span.setAttribute('data-page', pageNum);
                
                // Set active class
                if (pageNum === currentPage) {
                    span.className = 'page-num active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1';
                    span.style.width = '25px';
                    span.style.height = '25px';
                    span.style.fontSize = '0.8rem';
                } else {
                    span.className = 'page-num text-muted cursor-pointer mx-1';
                    span.style.width = 'auto';
                    span.style.height = 'auto';
                    span.style.fontSize = '0.9rem';
                }
            });

            // Update info text
            const start = ((currentPage - 1) * itemsPerPage) + 1;
            let end = currentPage * itemsPerPage;
            if (end > totalUsers) end = totalUsers;
            paginationInfo.textContent = `Showing ${start}-${end} of 2,482 users`;

            // Enforce condition to show max 10 users.
            // Since we only have 4 static rows, we show them on page 1, and hide them on other pages to simulate pagination.
            userRows.forEach((row, index) => {
                if (currentPage === 1 && index < 10) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        // Add click events to numbers
        middlePageNums.forEach(span => {
            span.addEventListener('click', function() {
                currentPage = parseInt(this.getAttribute('data-page'));
                updatePaginationUI();
            });
        });

        if (lastPageBtn) {
            lastPageBtn.addEventListener('click', function() {
                currentPage = 248;
                currentBlockStart = 246; // Show 246, 247, 248
                updatePaginationUI();
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                if (currentPage < 248) {
                    currentPage++;
                    if (currentPage >= currentBlockStart + 3) {
                        currentBlockStart = Math.min(245, currentBlockStart + 3);
                    }
                    updatePaginationUI();
                }
            });
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage--;
                    if (currentPage < currentBlockStart) {
                        currentBlockStart = Math.max(1, currentBlockStart - 3);
                    }
                    updatePaginationUI();
                }
            });
        }

        updatePaginationUI();
    }

    // 4.1 Pagination Logic for Places
    const placesPaginationContainer = document.getElementById('places-pagination');
    const placesPaginationInfo = document.getElementById('places-pagination-info');
    const placesPrevBtn = document.querySelector('.places-prev-page');
    const placesNextBtn = document.querySelector('.places-next-page');
    const placeRows = document.querySelectorAll('#v-pills-places .user-row');

    if (placesPaginationContainer && placesPaginationInfo) {
        const placesPageNumsNodes = placesPaginationContainer.querySelectorAll('.places-page-num');
        const placesMiddlePageNums = Array.from(placesPageNumsNodes).slice(0, 3);
        const placesLastPageBtn = placesPageNumsNodes[3]; 
        
        let currentPlacesBlockStart = 1;
        let currentPlacesPage = 1;
        const totalPlaces = 1284;
        const totalPlacesPages = Math.ceil(totalPlaces / 10);
        const itemsPerPlacesPage = 10;

        function updatePlacesPaginationUI() {
            placesMiddlePageNums.forEach((span, index) => {
                const pageNum = currentPlacesBlockStart + index;
                span.textContent = pageNum;
                span.setAttribute('data-page', pageNum);
                
                if (pageNum === currentPlacesPage) {
                    span.className = 'places-page-num active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1';
                    span.style.width = '25px';
                    span.style.height = '25px';
                    span.style.fontSize = '0.8rem';
                } else {
                    span.className = 'places-page-num text-muted cursor-pointer mx-1';
                    span.style.width = 'auto';
                    span.style.height = 'auto';
                    span.style.fontSize = '0.9rem';
                }
            });

            const start = ((currentPlacesPage - 1) * itemsPerPlacesPage) + 1;
            let end = currentPlacesPage * itemsPerPlacesPage;
            if (end > totalPlaces) end = totalPlaces;
            placesPaginationInfo.textContent = `Showing ${start}-${end} of 1,284 places`;

            placeRows.forEach((row, index) => {
                if (currentPlacesPage === 1 && index < itemsPerPlacesPage) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        placesMiddlePageNums.forEach(span => {
            span.addEventListener('click', function() {
                currentPlacesPage = parseInt(this.getAttribute('data-page'));
                updatePlacesPaginationUI();
            });
        });

        if (placesLastPageBtn) {
            placesLastPageBtn.addEventListener('click', function() {
                currentPlacesPage = totalPlacesPages;
                currentPlacesBlockStart = totalPlacesPages - 2; 
                updatePlacesPaginationUI();
            });
        }

        if (placesNextBtn) {
            placesNextBtn.addEventListener('click', () => {
                if (currentPlacesPage < totalPlacesPages) {
                    currentPlacesPage++;
                    if (currentPlacesPage >= currentPlacesBlockStart + 3) {
                        currentPlacesBlockStart = Math.min(totalPlacesPages - 2, currentPlacesBlockStart + 3);
                    }
                    updatePlacesPaginationUI();
                }
            });
        }

        if (placesPrevBtn) {
            placesPrevBtn.addEventListener('click', () => {
                if (currentPlacesPage > 1) {
                    currentPlacesPage--;
                    if (currentPlacesPage < currentPlacesBlockStart) {
                        currentPlacesBlockStart = Math.max(1, currentPlacesBlockStart - 3);
                    }
                    updatePlacesPaginationUI();
                }
            });
        }

        updatePlacesPaginationUI();
    }

    // 4.2 Pagination Logic for Packages
    const packagesPaginationContainer = document.getElementById('packages-pagination');
    const packagesPaginationInfo = document.getElementById('packages-pagination-info');
    const packagesPrevBtn = document.querySelector('.packages-prev-page');
    const packagesNextBtn = document.querySelector('.packages-next-page');
    const packageRows = document.querySelectorAll('.package-row');

    if (packagesPaginationContainer && packagesPaginationInfo) {
        const packagesPageNumsNodes = packagesPaginationContainer.querySelectorAll('.packages-page-num');
        const packagesMiddlePageNums = Array.from(packagesPageNumsNodes).slice(0, 3);
        const packagesLastPageBtn = packagesPageNumsNodes[3]; 
        
        let currentPackagesBlockStart = 1;
        let currentPackagesPage = 1;
        const totalPackages = 2482;
        const itemsPerPackagesPage = 10;

        function updatePackagesPaginationUI() {
            packagesMiddlePageNums.forEach((span, index) => {
                const pageNum = currentPackagesBlockStart + index;
                span.textContent = pageNum;
                span.setAttribute('data-page', pageNum);
                
                if (pageNum === currentPackagesPage) {
                    span.className = 'packages-page-num active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1';
                    span.style.width = '25px';
                    span.style.height = '25px';
                    span.style.fontSize = '0.8rem';
                } else {
                    span.className = 'packages-page-num text-muted cursor-pointer mx-1';
                    span.style.width = 'auto';
                    span.style.height = 'auto';
                    span.style.fontSize = '0.9rem';
                }
            });

            const start = ((currentPackagesPage - 1) * itemsPerPackagesPage) + 1;
            let end = currentPackagesPage * itemsPerPackagesPage;
            if (end > totalPackages) end = totalPackages;
            packagesPaginationInfo.textContent = `Showing ${start}-${end} of 2,482 packages`;

            packageRows.forEach((row, index) => {
                if (currentPackagesPage === 1 && index < itemsPerPackagesPage) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        packagesMiddlePageNums.forEach(span => {
            span.addEventListener('click', function() {
                currentPackagesPage = parseInt(this.getAttribute('data-page'));
                updatePackagesPaginationUI();
            });
        });

        if (packagesLastPageBtn) {
            packagesLastPageBtn.addEventListener('click', function() {
                currentPackagesPage = 248;
                currentPackagesBlockStart = 246; 
                updatePackagesPaginationUI();
            });
        }

        if (packagesNextBtn) {
            packagesNextBtn.addEventListener('click', () => {
                if (currentPackagesPage < 248) {
                    currentPackagesPage++;
                    if (currentPackagesPage >= currentPackagesBlockStart + 3) {
                        currentPackagesBlockStart = Math.min(245, currentPackagesBlockStart + 3);
                    }
                    updatePackagesPaginationUI();
                }
            });
        }

        if (packagesPrevBtn) {
            packagesPrevBtn.addEventListener('click', () => {
                if (currentPackagesPage > 1) {
                    currentPackagesPage--;
                    if (currentPackagesPage < currentPackagesBlockStart) {
                        currentPackagesBlockStart = Math.max(1, currentPackagesBlockStart - 3);
                    }
                    updatePackagesPaginationUI();
                }
            });
        }

        updatePackagesPaginationUI();
    }

    // 4.3 Pagination Logic for Feedback
    const feedbackPaginationContainer = document.getElementById('feedback-pagination');
    const feedbackPaginationInfo = document.getElementById('feedback-pagination-info');
    const feedbackPrevBtn = document.querySelector('.feedback-prev-page');
    const feedbackNextBtn = document.querySelector('.feedback-next-page');
    const feedbackRows = document.querySelectorAll('.feedback-row');

    if (feedbackPaginationContainer && feedbackPaginationInfo) {
        const feedbackPageNumsNodes = feedbackPaginationContainer.querySelectorAll('.feedback-page-num');
        const feedbackMiddlePageNums = Array.from(feedbackPageNumsNodes).slice(0, 3);
        const feedbackLastPageBtn = feedbackPageNumsNodes[3]; 
        
        let currentFeedbackBlockStart = 1;
        let currentFeedbackPage = 1;
        const totalFeedback = 2482;
        const itemsPerFeedbackPage = 10;

        function updateFeedbackPaginationUI() {
            feedbackMiddlePageNums.forEach((span, index) => {
                const pageNum = currentFeedbackBlockStart + index;
                span.textContent = pageNum;
                span.setAttribute('data-page', pageNum);
                
                if (pageNum === currentFeedbackPage) {
                    span.className = 'feedback-page-num active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1';
                    span.style.width = '25px';
                    span.style.height = '25px';
                    span.style.fontSize = '0.8rem';
                } else {
                    span.className = 'feedback-page-num text-muted cursor-pointer mx-1';
                    span.style.width = 'auto';
                    span.style.height = 'auto';
                    span.style.fontSize = '0.9rem';
                }
            });

            const start = ((currentFeedbackPage - 1) * itemsPerFeedbackPage) + 1;
            let end = currentFeedbackPage * itemsPerFeedbackPage;
            if (end > totalFeedback) end = totalFeedback;
            feedbackPaginationInfo.textContent = `Showing ${start}-${end} of 2,482 users`;

            feedbackRows.forEach((row, index) => {
                if (currentFeedbackPage === 1 && index < itemsPerFeedbackPage) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        feedbackMiddlePageNums.forEach(span => {
            span.addEventListener('click', function() {
                currentFeedbackPage = parseInt(this.getAttribute('data-page'));
                updateFeedbackPaginationUI();
            });
        });

        if (feedbackLastPageBtn) {
            feedbackLastPageBtn.addEventListener('click', function() {
                currentFeedbackPage = 248;
                currentFeedbackBlockStart = 246; 
                updateFeedbackPaginationUI();
            });
        }

        if (feedbackNextBtn) {
            feedbackNextBtn.addEventListener('click', () => {
                if (currentFeedbackPage < 248) {
                    currentFeedbackPage++;
                    if (currentFeedbackPage >= currentFeedbackBlockStart + 3) {
                        currentFeedbackBlockStart = Math.min(245, currentFeedbackBlockStart + 3);
                    }
                    updateFeedbackPaginationUI();
                }
            });
        }

        if (feedbackPrevBtn) {
            feedbackPrevBtn.addEventListener('click', () => {
                if (currentFeedbackPage > 1) {
                    currentFeedbackPage--;
                    if (currentFeedbackPage < currentFeedbackBlockStart) {
                        currentFeedbackBlockStart = Math.max(1, currentFeedbackBlockStart - 3);
                    }
                    updateFeedbackPaginationUI();
                }
            });
        }

        updateFeedbackPaginationUI();
    }

    // 4.4 Pagination Logic for Tickets
    const ticketsPaginationContainer = document.getElementById('ticket-pagination');
    const ticketsPaginationInfo = document.getElementById('ticket-pagination-info');
    const ticketsPrevBtn = document.querySelector('.ticket-prev-page');
    const ticketsNextBtn = document.querySelector('.ticket-next-page');
    const ticketRows = document.querySelectorAll('.ticket-row');

    if (ticketsPaginationContainer && ticketsPaginationInfo) {
        const ticketsPageNumsNodes = ticketsPaginationContainer.querySelectorAll('.ticket-page-num');
        const ticketsMiddlePageNums = Array.from(ticketsPageNumsNodes).slice(0, 3);
        const ticketsLastPageBtn = ticketsPageNumsNodes[3]; 
        
        let currentTicketsBlockStart = 1;
        let currentTicketsPage = 1;
        const totalTickets = 2482;
        const itemsPerTicketsPage = 10;

        function updateTicketsPaginationUI() {
            ticketsMiddlePageNums.forEach((span, index) => {
                const pageNum = currentTicketsBlockStart + index;
                span.textContent = pageNum;
                span.setAttribute('data-page', pageNum);
                
                if (pageNum === currentTicketsPage) {
                    span.className = 'ticket-page-num active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1';
                    span.style.width = '25px';
                    span.style.height = '25px';
                    span.style.fontSize = '0.8rem';
                } else {
                    span.className = 'ticket-page-num text-muted cursor-pointer mx-1';
                    span.style.width = 'auto';
                    span.style.height = 'auto';
                    span.style.fontSize = '0.9rem';
                }
            });

            const start = ((currentTicketsPage - 1) * itemsPerTicketsPage) + 1;
            let end = currentTicketsPage * itemsPerTicketsPage;
            if (end > totalTickets) end = totalTickets;
            ticketsPaginationInfo.textContent = `Showing ${start}-${end} of 2,482 tickets`;

            ticketRows.forEach((row, index) => {
                if (currentTicketsPage === 1 && index < itemsPerTicketsPage) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        ticketsMiddlePageNums.forEach(span => {
            span.addEventListener('click', function() {
                currentTicketsPage = parseInt(this.getAttribute('data-page'));
                updateTicketsPaginationUI();
            });
        });

        if (ticketsLastPageBtn) {
            ticketsLastPageBtn.addEventListener('click', function() {
                currentTicketsPage = 248;
                currentTicketsBlockStart = 246; 
                updateTicketsPaginationUI();
            });
        }

        if (ticketsNextBtn) {
            ticketsNextBtn.addEventListener('click', () => {
                if (currentTicketsPage < 248) {
                    currentTicketsPage++;
                    if (currentTicketsPage >= currentTicketsBlockStart + 3) {
                        currentTicketsBlockStart = Math.min(245, currentTicketsBlockStart + 3);
                    }
                    updateTicketsPaginationUI();
                }
            });
        }

        if (ticketsPrevBtn) {
            ticketsPrevBtn.addEventListener('click', () => {
                if (currentTicketsPage > 1) {
                    currentTicketsPage--;
                    if (currentTicketsPage < currentTicketsBlockStart) {
                        currentTicketsBlockStart = Math.max(1, currentTicketsBlockStart - 3);
                    }
                    updateTicketsPaginationUI();
                }
            });
        }

        updateTicketsPaginationUI();
    }

    // 5. Custom Filter Dropdowns Logic
    const filterDropdowns = document.querySelectorAll('.filter-dropdown');
    filterDropdowns.forEach(dropdown => {
        const btnText = dropdown.querySelector('.dropdown-text');
        const items = dropdown.querySelectorAll('.dropdown-item');
        
        items.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Update main button text
                const value = this.getAttribute('data-value');
                btnText.textContent = value;
                
                // Remove active styling from all items
                items.forEach(i => {
                    i.classList.remove('active-item');
                    const icon = i.querySelector('.item-icon');
                    if (icon) icon.classList.add('d-none');
                });
                
                // Add active styling to clicked item
                this.classList.add('active-item');
                const activeIcon = this.querySelector('.item-icon');
                if (activeIcon) activeIcon.classList.remove('d-none');
            });
        });
    });

    // 6. Edit & Delete Logic (Users & Places)
    // currentEditType = null; // 'user' or 'place' (removing duplicate declaration)
    let currentEditType = null; // 'user' or 'place'

    document.addEventListener('click', function(e) {
        // Handle Upload Button Click (Global)
        if (e.target.closest('.upload-trigger')) {
            const targetId = e.target.closest('.upload-trigger').getAttribute('data-target');
            const fileInput = document.querySelector(targetId);
            if (fileInput) fileInput.click();
        }

        // Handle Edit Button Click
        if (e.target.closest('.edit-btn')) {
            currentRow = e.target.closest('tr');
            
            // Check if it's a User, Place or Package
            const isUserTable = currentRow.closest('#v-pills-users');
            const isPlaceTable = currentRow.closest('#v-pills-places');
            const isPackageTable = currentRow.closest('#v-pills-packages');
            const isOfferTable = currentRow.closest('#v-pills-offers');
            const isBookingTable = currentRow.closest('#v-pills-bookings') || currentRow.closest('#bookingsTable');

            if (isUserTable) {
                currentEditType = 'user';
                const name = currentRow.querySelector('h6').textContent.trim();
                const email = currentRow.cells[1].textContent.trim();
                const status = currentRow.querySelector('.badge').textContent.trim();

                document.getElementById('editUserName').value = name;
                document.getElementById('editUserEmail').value = email;

                if (status.includes('Active')) {
                    document.getElementById('editStatusActive').checked = true;
                } else {
                    document.getElementById('editStatusInactive').checked = true;
                }
            } else if (isPlaceTable) {
                currentEditType = 'place';
                const name = currentRow.cells[2].textContent.trim();
                const location = currentRow.cells[3].textContent.trim();
                const category = currentRow.cells[4].textContent.trim();
                const ratingText = currentRow.cells[5].textContent.trim();

                document.getElementById('editPlaceName').value = name;
                document.getElementById('editPlaceLocation').value = location;
                document.getElementById('editPlaceRating').value = ratingText;
                document.getElementById('editPlaceDescription').value = ""; 

                // Update Category Dropdown
                const categoryInput = document.getElementById('editPlaceCategory');
                if (categoryInput) categoryInput.value = category;
                const categorySpan = document.getElementById('editPlaceCategoryValue');
                if (categorySpan) categorySpan.textContent = category;
            } else if (currentRow.closest('#v-pills-hidden-gems')) {
                currentEditType = 'gem';
                const name = currentRow.cells[2].textContent.trim();
                const location = currentRow.cells[3].textContent.trim();
                const category = currentRow.cells[4].textContent.trim();
                const ratingText = currentRow.cells[6].textContent.trim().replace('4.8', '').trim() || currentRow.cells[6].textContent.trim();
                
                document.getElementById('editGemName').value = name;
                document.getElementById('editGemLocation').value = location;
                document.getElementById('editGemRating').value = ratingText;
                
                // Update Category Dropdown
                const categoryInput = document.getElementById('editGemCategory');
                if (categoryInput) categoryInput.value = category;
                const categorySpan = document.getElementById('editGemCategoryValue');
                if (categorySpan) categorySpan.textContent = category;
            } else if (isPackageTable) {
                currentEditType = 'package';
                const name = currentRow.cells[2].textContent.trim();
                const ratingText = currentRow.cells[5].textContent.trim();
                
                // Get all place names from the badges
                const placeBadges = currentRow.cells[3].querySelectorAll('.badge');
                const places = Array.from(placeBadges).map(b => b.textContent.trim());

                document.getElementById('editPackageName').value = name;
                document.getElementById('editPackageDescription').value = ""; 
                document.getElementById('editPackageRating').value = ratingText;

                // Update Category Dropdown
                const categoryValue = "Cultural"; // Default logic
                const categoryInput = document.getElementById('editPackageCategory');
                if (categoryInput) categoryInput.value = categoryValue;
                const categorySpan = document.getElementById('editPackageCategoryValue');
                if (categorySpan) categorySpan.textContent = categoryValue;

                // Reset and Check checkboxes
                const container = document.getElementById('editPackageIncludedPlacesContainer');
                if (container) {
                    const checkboxes = container.querySelectorAll('input[type="checkbox"]');
                    checkboxes.forEach(cb => {
                        cb.checked = places.some(p => p.toLowerCase().includes(cb.value.toLowerCase()));
                    });
                }
            } else if (isOfferTable) {
                currentEditType = 'offer';
                const title = currentRow.cells[1].textContent.trim();
                const discount = currentRow.cells[2].textContent.trim();
                const appliedTo = currentRow.cells[3].textContent.trim();
                const startDate = currentRow.cells[4].textContent.trim();
                const endDate = currentRow.cells[5].textContent.trim();

                document.getElementById('editOfferTitle').value = title;
                document.getElementById('editOfferDiscount').value = discount;
                document.getElementById('editOfferStartDate').value = startDate;
                document.getElementById('editOfferEndDate').value = endDate;

                if (appliedTo.toLowerCase().includes('package')) {
                    document.getElementById('editApplyPackage').checked = true;
                } else {
                    document.getElementById('editApplyPlace').checked = true;
                }
            } else if (isBookingTable) {
                currentEditType = 'booking';
                const bookingId = currentRow.cells[0].textContent.trim();
                const userName = currentRow.cells[1].textContent.trim();
                const item = currentRow.cells[2].textContent.trim();
                const statusText = currentRow.cells[6].textContent.trim();

                document.getElementById('editBookingId').value = bookingId;
                document.getElementById('editBookingUserName').value = userName;
                document.getElementById('editBookingItem').value = item;

                if (statusText.includes('Confirmed')) {
                    document.getElementById('bookingStatusConfirmed').checked = true;
                } else if (statusText.includes('Pending')) {
                    document.getElementById('bookingStatusPending').checked = true;
                } else if (statusText.includes('Canceled') || statusText.includes('Cancelled')) {
                    document.getElementById('bookingStatusCancelled').checked = true;
                } else if (statusText.includes('Rejected')) {
                    document.getElementById('bookingStatusRejected').checked = true;
                }
            } else if (currentRow.closest('#v-pills-tickets')) {
                currentEditType = 'ticket';
                const place = currentRow.cells[1].textContent.trim();
                const audience = currentRow.cells[2].textContent.trim();
                const type = currentRow.cells[3].textContent.trim();
                const priceText = currentRow.cells[4].textContent.trim();
                const status = currentRow.querySelector('.badge').textContent.trim();

                const [price, currency] = priceText.split(' ');

                document.getElementById('editTicketPlace').value = place;
                document.getElementById('editTicketAudience').value = audience;
                document.getElementById('editTicketType').value = type;
                document.getElementById('editTicketPrice').value = price;
                document.getElementById('editTicketCurrency').value = currency;
                document.getElementById('editTicketStatus').value = status.includes('Active') ? 'Active' : 'Inactive';

                // Manually show the modal
                const modalEl = document.getElementById('editTicketModal');
                if (modalEl) {
                    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                    modal.show();
                }
            }
        }

        // Handle View Booking Button Click
        if (e.target.closest('.view-booking-btn')) {
            const row = e.target.closest('tr');
            const userName = row.cells[1].textContent.trim();
            const item = row.cells[2].textContent.trim();
            const date = row.cells[3].textContent.trim();
            const tickets = row.cells[4].textContent.trim();
            const price = row.cells[5].textContent.trim();

            document.getElementById('detailsBookingUserName').value = userName;
            document.getElementById('detailsBookingItem').value = item;
            document.getElementById('detailsBookingDate').value = date;
            document.getElementById('detailsBookingTickets').value = tickets;
            document.getElementById('detailsBookingPrice').value = price;
        }

        // Handle View Feedback Button Click
        if (e.target.closest('.view-feedback-btn')) {
            e.preventDefault(); // Prevent any default action
            currentRow = e.target.closest('tr');
            
            const h6 = currentRow.cells[0].querySelector('h6');
            const userName = h6 ? h6.textContent.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim() : 'Unknown User';
            const comment = currentRow.cells[3] ? currentRow.cells[3].textContent.trim() : '';
            const statusBadgeText = currentRow.cells[4] ? currentRow.cells[4].textContent.trim() : '';

            document.getElementById('feedbackDetailsId').value = "#" + (Math.floor(Math.random() * 9000) + 1000); // Random ID for demo
            document.getElementById('feedbackDetailsName').value = userName;
            document.getElementById('feedbackDetailsComment').value = comment;

            const statusRadios = document.getElementsByName('feedbackDetailsStatus');
            for (let radio of statusRadios) {
                if (statusBadgeText.includes(radio.value)) {
                    radio.checked = true;
                }
            }

            // Manually show the modal
            const modalEl = document.getElementById('feedbackDetailsModal');
            if (modalEl) {
                const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                modal.show();
            }
        }


        // Handle Delete Button Click
        if (e.target.closest('.delete-btn')) {
            currentRow = e.target.closest('tr');
            // If it's a ticket, we can use a specific confirmation or just the generic one
        }

        // Handle Edit Ticket Button Click (Specific class)
        if (e.target.closest('.edit-ticket-btn')) {
            currentRow = e.target.closest('tr');
            currentEditType = 'ticket';
            
            const place = currentRow.cells[1].textContent.trim();
            const audience = currentRow.cells[2].textContent.trim();
            const type = currentRow.cells[3].textContent.trim();
            const priceText = currentRow.cells[4].textContent.trim();
            const status = currentRow.querySelector('.badge').textContent.trim();

            const [price, currency] = priceText.split(' ');

            document.getElementById('editTicketPlace').value = place;
            
            // Set radio buttons
            const audienceRadio = document.querySelector(`input[name="editTicketAudience"][value="${audience}"]`);
            if (audienceRadio) audienceRadio.checked = true;

            const typeRadio = document.querySelector(`input[name="editTicketType"][value="${type}"]`);
            if (typeRadio) typeRadio.checked = true;

            document.getElementById('editTicketPrice').value = price;
            document.getElementById('editTicketCurrency').value = currency;
            
            const normalizedStatus = status.includes('Active') ? 'Active' : 'Inactive';
            const statusRadio = document.querySelector(`input[name="editTicketStatus"][value="${normalizedStatus}"]`);
            if (statusRadio) statusRadio.checked = true;

            const modalEl = document.getElementById('editTicketModal');
            if (modalEl) {
                const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                modal.show();
            }
        }

        // Handle Quick Status Toggle (Yellow Icon)
        if (e.target.closest('.status-toggle-btn')) {
            const row = e.target.closest('tr');
            const badge = row.querySelector('.status-badge');
            if (!badge) return;
            const isCurrentlyActive = badge.textContent.trim().includes('Active');
            const isOffer = row.classList.contains('offer-row');
            const inactiveText = isOffer ? 'Expired' : 'Inactive';

            if (isCurrentlyActive) {
                badge.className = 'badge status-badge bg-secondary bg-opacity-10 rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                badge.style.color = '#242448';
                badge.innerHTML = `<span class="rounded-circle" style="width: 6px; height: 6px; background-color: #242448;"></span> ${inactiveText}`;
            } else {
                badge.className = 'badge status-badge bg-success-subtle text-success rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                badge.style.color = '';
                badge.innerHTML = '<span class="rounded-circle bg-success" style="width: 6px; height: 6px;"></span> Active';
            }
        }
    });

    // Handle Edit Form Submit (User)
    const editUserForm = document.getElementById('editUserForm');
    if (editUserForm) {
        editUserForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (currentRow && currentEditType === 'user') {
                const newName = document.getElementById('editUserName').value;
                const newEmail = document.getElementById('editUserEmail').value;
                const isActive = document.getElementById('editStatusActive').checked;

                currentRow.querySelector('h6').textContent = newName;
                currentRow.cells[1].textContent = newEmail;
                const badge = currentRow.querySelector('.status-badge');
                if (isActive) {
                    badge.className = 'badge status-badge bg-success-subtle text-success rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                    badge.innerHTML = '<span class="rounded-circle bg-success" style="width: 6px; height: 6px;"></span> Active';
                } else {
                    badge.className = 'badge status-badge bg-secondary bg-opacity-10 rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                    badge.style.color = '#242448';
                    badge.innerHTML = '<span class="rounded-circle" style="width: 6px; height: 6px; background-color: #242448;"></span> Inactive';
                }

                const modal = bootstrap.Modal.getInstance(document.getElementById('editUserModal'));
                if (modal) modal.hide();
            }
        });
    }

    // Handle Feedback Details Form Submit
    const feedbackDetailsForm = document.getElementById('feedbackDetailsForm');
    if (feedbackDetailsForm) {
        feedbackDetailsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (currentRow && currentRow.closest('#v-pills-feedback')) {
                const selectedRadio = document.querySelector('input[name="feedbackDetailsStatus"]:checked');
                if (selectedRadio) {
                    const status = selectedRadio.value;
                    const badge = currentRow.querySelector('.status-badge');
                    
                    if (status === 'Confirmed') {
                        badge.className = 'badge status-badge bg-success-subtle text-success rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                        badge.innerHTML = '<span class="rounded-circle bg-success" style="width: 6px; height: 6px;"></span> Confirmed';
                    } else if (status === 'Pending') {
                        badge.className = 'badge status-badge bg-warning-subtle text-warning rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                        badge.innerHTML = '<span class="rounded-circle bg-warning" style="width: 6px; height: 6px;"></span> Pending';
                    } else if (status === 'Rejected') {
                        badge.className = 'badge status-badge bg-danger-subtle text-danger rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2';
                        badge.innerHTML = '<span class="rounded-circle bg-danger" style="width: 6px; height: 6px;"></span> Rejected';
                    }
                }

                const modal = bootstrap.Modal.getInstance(document.getElementById('feedbackDetailsModal'));
                if (modal) modal.hide();
            }
        });
    }

    // Handle Edit Form Submit (Place)
    const editPlaceForm = document.getElementById('editPlaceForm');
    if (editPlaceForm) {
        editPlaceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (currentRow && currentEditType === 'place') {
                const newName = document.getElementById('editPlaceName').value;
                const newLocation = document.getElementById('editPlaceLocation').value;
                const newCategory = document.getElementById('editPlaceCategory').value;
                const newRating = document.getElementById('editPlaceRating').value;

                currentRow.cells[2].innerHTML = `<div class="fw-medium" style="color: #242448;">${newName}</div>`;
                currentRow.cells[3].textContent = newLocation;
                currentRow.cells[4].textContent = newCategory;
                currentRow.cells[5].innerHTML = `<i class="fas fa-star text-warning me-1"></i>${newRating}`;

                const modal = bootstrap.Modal.getInstance(document.getElementById('editPlaceModal'));
                if (modal) modal.hide();
            }
        });
    }

    // Handle Edit Form Submit (Package)
    const editPackageForm = document.getElementById('editPackageForm');
    if (editPackageForm) {
        editPackageForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (currentRow && currentEditType === 'package') {
                const newName = document.getElementById('editPackageName').value;
                const newRating = document.getElementById('editPackageRating').value;
                const newCategory = document.getElementById('editPackageCategory').value;

                currentRow.cells[2].textContent = newName;
                currentRow.cells[5].innerHTML = `<i class="fas fa-star text-warning me-1"></i>${newRating}`;

                const modal = bootstrap.Modal.getInstance(document.getElementById('editPackageModal'));
                if (modal) modal.hide();
            }
        });
    }

    // Handle Edit Form Submit (Offer)
    const editOfferForm = document.getElementById('editOfferForm');
    if (editOfferForm) {
        editOfferForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (currentRow && currentEditType === 'offer') {
                const newTitle = document.getElementById('editOfferTitle').value;
                const newDiscount = document.getElementById('editOfferDiscount').value;
                const newStartDate = document.getElementById('editOfferStartDate').value;
                const newEndDate = document.getElementById('editOfferEndDate').value;
                
                const selectedRadio = document.querySelector('input[name="editApplyTo"]:checked');
                const applyToText = selectedRadio.nextElementSibling.textContent.trim();

                currentRow.cells[1].textContent = newTitle;
                currentRow.cells[2].textContent = newDiscount;
                currentRow.cells[3].textContent = applyToText;
                currentRow.cells[4].textContent = newStartDate;
                currentRow.cells[5].textContent = newEndDate;

                const modal = bootstrap.Modal.getInstance(document.getElementById('editOfferModal'));
                if (modal) modal.hide();
            }
        });
    }



    // Handle Confirm Delete (Generic)
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener('click', function() {
            if (currentRow) {
                currentRow.remove();
                const userModal = bootstrap.Modal.getInstance(document.getElementById('deleteUserModal'));
                if (userModal) userModal.hide();
                currentRow = null;
            }
        });
    }

    const confirmDeletePlaceBtn = document.querySelector('#deletePlaceModal button.theme-btn');
    if (confirmDeletePlaceBtn) {
        confirmDeletePlaceBtn.addEventListener('click', function() {
            if (currentRow) {
                currentRow.remove();
                const placeModal = bootstrap.Modal.getInstance(document.getElementById('deletePlaceModal'));
                if (placeModal) placeModal.hide();
                currentRow = null;
            }
        });
    }

    const confirmDeletePackageBtn = document.getElementById('confirmDeletePackageBtn');
    if (confirmDeletePackageBtn) {
        confirmDeletePackageBtn.addEventListener('click', function() {
            if (currentRow) {
                currentRow.remove();
                const packageModal = bootstrap.Modal.getInstance(document.getElementById('deletePackageModal'));
                if (packageModal) packageModal.hide();
                currentRow = null;
            }
        });
    }
    // Handle Multi-select dropdown text update
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('form-check-input') && e.target.closest('.custom-multi-select')) {
            const container = e.target.closest('.custom-multi-select');
            const countSpan = container.querySelector('.selected-count');
            const checkedCount = container.querySelectorAll('input[type="checkbox"]:checked').length;
            
            if (checkedCount === 0) {
                countSpan.textContent = "Select places..";
            } else if (checkedCount === 1) {
                const firstLabel = container.querySelector('input[type="checkbox"]:checked + label').textContent;
                countSpan.textContent = firstLabel;
            } else {
                countSpan.textContent = `${checkedCount} places selected`;
            }
        }
    });

    // Handle Custom Single-select dropdown
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('dropdown-item') && e.target.closest('.custom-single-select')) {
            e.preventDefault();
            const container = e.target.closest('.custom-single-select');
            const value = e.target.getAttribute('data-value');
            const text = e.target.textContent;
            
            const valueSpan = container.querySelector('.selected-value');
            if (valueSpan) valueSpan.textContent = text;
            
            const hiddenInput = container.querySelector('input[type="hidden"]');
            if (hiddenInput) hiddenInput.value = value;
        }
    });
    // 8. Hidden Gems Pagination Logic
    const gemsPaginationContainer = document.getElementById('gems-pagination');
    if (gemsPaginationContainer) {
        const gemsPageNumsNodes = gemsPaginationContainer.querySelectorAll('.gems-page-num');
        const gemsMiddlePageNums = Array.from(gemsPageNumsNodes).slice(0, 3);
        const gemsLastPageBtn = gemsPageNumsNodes[3]; 

        let currentGemsBlockStart = 1;
        let currentGemsPage = 1;
        const totalGemsPages = 129;

        function updateGemsPaginationUI() {
            gemsMiddlePageNums.forEach((span, index) => {
                const pageNum = currentGemsBlockStart + index;
                if (pageNum < totalGemsPages) {
                    span.textContent = pageNum;
                    span.setAttribute('data-page', pageNum);
                    span.style.display = '';
                    
                    if (pageNum === currentGemsPage) {
                        span.className = 'gems-page-num active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1';
                        span.style.width = '25px';
                        span.style.height = '25px';
                        span.style.fontSize = '0.8rem';
                    } else {
                        span.className = 'gems-page-num text-muted cursor-pointer mx-1';
                        span.style.width = 'auto';
                        span.style.height = 'auto';
                        span.style.fontSize = '0.9rem';
                    }
                } else {
                    span.style.display = 'none';
                }
            });

            const info = document.getElementById('gems-pagination-info');
            const gemRows = document.querySelectorAll('.gem-row');
            
            if (info) {
                const start = (currentGemsPage - 1) * 10 + 1;
                const end = Math.min(currentGemsPage * 10, 1284);
                info.textContent = `Showing ${start}-${end} of 1,284 gems`;
            }

            gemRows.forEach((row, index) => {
                if (currentGemsPage === 1 && index < 10) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        gemsMiddlePageNums.forEach(span => {
            // Old Users Pagination Logic Removed (Handled by setupPagination)
            span.addEventListener('click', function() {
                currentGemsPage = parseInt(this.getAttribute('data-page'));
                updateGemsPaginationUI();
            });
        });

        if (gemsLastPageBtn) {
            gemsLastPageBtn.addEventListener('click', function() {
                currentGemsPage = totalGemsPages;
                currentGemsBlockStart = Math.max(1, totalGemsPages - 3);
                updateGemsPaginationUI();
            });
        }

        const prevBtn = gemsPaginationContainer.querySelector('.gems-prev-page');
        const nextBtn = gemsPaginationContainer.querySelector('.gems-next-page');

        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (currentGemsPage > 1) {
                    currentGemsPage--;
                    if (currentGemsPage < currentGemsBlockStart) {
                        currentGemsBlockStart = Math.max(1, currentGemsBlockStart - 3);
                    }
                    updateGemsPaginationUI();
                }
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                if (currentGemsPage < totalGemsPages) {
                    currentGemsPage++;
                    if (currentGemsPage >= currentGemsBlockStart + 3) {
                        currentGemsBlockStart = Math.min(totalGemsPages - 3, currentGemsBlockStart + 3);
                    }
                    updateGemsPaginationUI();
                }
            });
        }
    }

    // 9. Image Preview Logic for Add/Edit Gem & Place Modals
    const addGemInput = document.getElementById('addGemImageInput');
    if (addGemInput) {
        addGemInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('addGemPreview');
                    preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover;">`;
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    const editGemInput = document.getElementById('editGemImageInput');
    if (editGemInput) {
        editGemInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('editGemPreview');
                    preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover;">`;
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    const addPlaceInput = document.getElementById('addPlaceImageInput');
    if (addPlaceInput) {
        addPlaceInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('addPlacePreview');
                    preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover;">`;
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    const editPlaceInput = document.getElementById('editPlaceImageInput');
    if (editPlaceInput) {
        editPlaceInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('editPlacePreview');
                    preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover;">`;
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    // Old Offers Pagination Logic Removed (Handled by setupPagination)
    // Status Toggle Logic for Events
    const eventToggleButtons = document.querySelectorAll('.status-toggle-btn');
    eventToggleButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const statusBadge = row.querySelector('.badge');
            const statusText = statusBadge.textContent.trim();
            const statusDot = statusBadge.querySelector('span');

            if (statusText === 'Active') {
                statusBadge.style.color = '#94a3b8';
                statusBadge.className = 'badge bg-secondary bg-opacity-10 rounded-pill px-3 py-2 fw-medium';
                statusDot.style.backgroundColor = '#94a3b8';
                statusBadge.innerHTML = '<span class="rounded-circle d-inline-block me-1" style="width: 6px; height: 6px; background-color: #94a3b8;"></span> Inactive';
            } else {
                statusBadge.style.color = '#22c55e';
                statusBadge.className = 'badge bg-success bg-opacity-10 rounded-pill px-3 py-2 fw-medium';
                statusDot.style.backgroundColor = '#22c55e';
                statusBadge.innerHTML = '<span class="rounded-circle d-inline-block me-1" style="width: 6px; height: 6px; background-color: #22c55e;"></span> Active';
            }
        });
    });

    // Pagination Logic for Events and Gems
    function setupPagination(prefix, totalItems, itemsPerPage = 10, label = '') {
        const paginationContainer = document.getElementById(`${prefix}-pagination`);
        if (!paginationContainer) return;

        const infoText = document.getElementById(`${prefix}-pagination-info`) || document.getElementById('pagination-info');
        const pageNums = Array.from(paginationContainer.querySelectorAll(`.${prefix}-page-num`)).length > 0 
                         ? Array.from(paginationContainer.querySelectorAll(`.${prefix}-page-num`))
                         : Array.from(paginationContainer.querySelectorAll('.page-num'));
        
        const prevBtn = paginationContainer.querySelector(`.${prefix}-prev-page`) || paginationContainer.querySelector('.prev-page');
        const nextBtn = paginationContainer.querySelector(`.${prefix}-next-page`) || paginationContainer.querySelector('.next-page');
        
        // Dynamic row selection based on prefix
        let rowClass = prefix.endsWith('s') ? prefix.slice(0, -1) : prefix;
        if (prefix === 'gems') rowClass = 'gem';
        const rows = document.querySelectorAll(`.${rowClass}-row`);
        
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        let currentPage = 1;
        let currentBlockStart = 1;

        const middleButtons = pageNums.slice(0, 3);
        const lastButton = pageNums[pageNums.length - 1];

        const itemLabel = label || (prefix.endsWith('s') ? prefix : prefix + 's');

        function updateUI() {
            middleButtons.forEach((span, index) => {
                const pageNum = currentBlockStart + index;
                if (pageNum <= totalPages) {
                    span.textContent = pageNum;
                    span.setAttribute('data-page', pageNum);
                    span.style.display = '';
                    
                    if (pageNum === currentPage) {
                        span.className = `${span.classList[0]} active-page rounded-1 theme-bg text-white d-flex align-items-center justify-content-center cursor-pointer shadow-sm mx-1`;
                        span.style.width = '25px';
                        span.style.height = '25px';
                        span.style.fontSize = '0.8rem';
                    } else {
                        span.className = `${span.classList[0]} text-muted cursor-pointer mx-1`;
                        span.style.width = 'auto';
                        span.style.height = 'auto';
                        span.style.fontSize = '0.9rem';
                    }
                } else {
                    span.style.display = 'none';
                }
            });

            const separator = paginationContainer.querySelector('.text-muted.mx-1:not(.' + prefix + '-page-num):not(.page-num)');
            if (lastButton) {
                if (currentBlockStart + 3 >= totalPages) {
                    if (separator) separator.style.display = 'none';
                    lastButton.style.display = 'none';
                } else {
                    if (separator) separator.style.display = '';
                    lastButton.style.display = '';
                    lastButton.textContent = totalPages;
                    lastButton.setAttribute('data-page', totalPages);
                }
            }

            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            rows.forEach((row, index) => {
                if (index >= start && index < end) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });

            if (infoText) {
                const actualEnd = Math.min(end, totalItems);
                infoText.textContent = `Showing ${start + 1}-${actualEnd} of ${totalItems.toLocaleString()} ${itemLabel}`;
            }
        }

        middleButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                currentPage = parseInt(this.getAttribute('data-page'));
                updateUI();
            });
        });

        if (lastButton) {
            lastButton.addEventListener('click', function() {
                currentPage = totalPages;
                currentBlockStart = Math.max(1, totalPages - 2);
                updateUI();
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                if (currentPage < totalPages) {
                    currentPage++;
                    if (currentPage >= currentBlockStart + 3) {
                        currentBlockStart = Math.min(totalPages - 2, currentBlockStart + 3);
                    }
                    updateUI();
                }
            });
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage--;
                    if (currentPage < currentBlockStart) {
                        currentBlockStart = Math.max(1, currentBlockStart - 3);
                    }
                    updateUI();
                }
            });
        }

        updateUI();
    }

    // Initialize Pagination for all sections
    setupPagination('users', 2482, 10, 'users');
    setupPagination('places', 1284, 10, 'places');
    setupPagination('packages', 1284, 10, 'packages');
    setupPagination('events', 24, 10, 'events');
    setupPagination('gems', 1284, 10, 'hidden gems');
    setupPagination('bookings', 2482, 10, 'bookings');
    setupPagination('offers', 2482, 10, 'offers');
    setupPagination('feedback', 2482, 10, 'feedbacks');
    setupPagination('ticket', 2482, 10, 'tickets');

    // Custom Single Select Logic (Modals)
    document.querySelectorAll('.custom-single-select').forEach(select => {
        const btn = select.querySelector('.dropdown-toggle');
        const display = btn.querySelector('.selected-value');
        const items = select.querySelectorAll('.dropdown-item');
        const otherContainer = select.querySelector('.other-time-container');
        const otherInput = select.querySelector('.other-time-input');
        const backBtn = select.querySelector('.back-to-list');

        items.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const val = this.getAttribute('data-value');
                
                if (val === 'Other') {
                    btn.classList.add('d-none');
                    if (otherContainer) {
                        otherContainer.classList.remove('d-none');
                        if (otherInput) otherInput.focus();
                    }
                } else {
                    if (display) display.textContent = val;
                }
            });
        });

        if (backBtn) {
            backBtn.addEventListener('click', () => {
                if (otherContainer) otherContainer.classList.add('d-none');
                btn.classList.remove('d-none');
                if (display) display.textContent = 'Select time slots....';
            });
        }
    });

    console.log("Gawla Dashboard Script Loaded Successfully");
    // Manually initialize all dropdowns to ensure functionality
    const dropdownTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="dropdown"]'));
    // Fail-safe: Manually toggle dropdowns if Bootstrap logic is blocked
    document.addEventListener('click', function (e) {
        const toggle = e.target.closest('[data-bs-toggle="dropdown"]');
        if (toggle) {
            const menu = toggle.nextElementSibling;
            if (menu && menu.classList.contains('dropdown-menu')) {
                // Let Bootstrap handle it first, but if it doesn't show, we force it
                setTimeout(() => {
                    if (!menu.classList.contains('show')) {
                        console.log("Forcing dropdown show via manual script");
                        const dp = bootstrap.Dropdown.getOrCreateInstance(toggle);
                        dp.toggle();
                    }
                }, 50);
            }
        }
    });
    // Log for confirmation
    console.log("Ticket logic initialization complete");

    // 5. Offer Filter Dropdown Logic (Generic for Tickets and Offers)
    document.querySelectorAll('.offer-filter-dropdown').forEach(dropdown => {
        const btn = dropdown.querySelector('.dropdown-toggle');
        const header = dropdown.querySelector('.dropdown-header-custom');
        const items = dropdown.querySelectorAll('.dropdown-item-custom');

        if (header) {
            header.addEventListener('click', function(e) {
                e.stopPropagation();
                const dp = bootstrap.Dropdown.getInstance(btn);
                if (dp) dp.hide();
            });
        }

        items.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const text = this.textContent.trim();
                btn.innerHTML = `${text} <i class="fas fa-chevron-down ms-2 small"></i>`;
                
                // Add active class
                items.forEach(i => i.classList.remove('active-filter'));
                this.classList.add('active-filter');

                // If it's the tickets tab, trigger filtering
                if (dropdown.closest('#v-pills-tickets')) {
                    filterTicketsTable();
                }
            });
        });
    });

    // 6. Ticket Search Logic
    const ticketSearchInput = document.getElementById('ticket-search-input');
    if (ticketSearchInput) {
        ticketSearchInput.addEventListener('input', function() {
            filterTicketsTable();
        });
    }

    function filterTicketsTable() {
        if (!ticketSearchInput) return;
        const searchTerm = ticketSearchInput.value.toLowerCase();
        
        // Get active filter values from buttons in the tickets section
        const ticketFilters = document.querySelectorAll('#v-pills-tickets .offer-filter-dropdown .dropdown-toggle');
        if (ticketFilters.length < 3) return;

        const audienceFilter = ticketFilters[0].textContent.trim();
        const typeFilter = ticketFilters[1].textContent.trim();
        const statusFilter = ticketFilters[2].textContent.trim();

        document.querySelectorAll('.ticket-row').forEach(row => {
            const place = row.cells[1].textContent.toLowerCase();
            const audience = row.cells[2].textContent.trim();
            const type = row.cells[3].textContent.trim();
            const statusBadge = row.querySelector('.status-badge');
            const status = statusBadge ? statusBadge.textContent.trim() : "";

            const matchesSearch = place.includes(searchTerm);
            const matchesAudience = audienceFilter === 'Audience' || audienceFilter === 'All' || audience === audienceFilter;
            const matchesType = typeFilter === 'Ticket Type' || typeFilter === 'All' || type === typeFilter;
            const matchesStatus = statusFilter === 'Status' || statusFilter === 'All' || status === statusFilter;

            if (matchesSearch && matchesAudience && matchesType && matchesStatus) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Profile Page Logic
    window.enableInput = function(inputId) {
        const input = document.getElementById(inputId);
        if (input) {
            input.readOnly = false;
            input.focus();
            const btn = input.nextElementSibling;
            if (btn && btn.classList.contains('profile-change-btn')) {
                btn.style.display = 'none';
            }
        }
    };

    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log("Profile form submitted!");
            
            // Show custom toast
            const toast = document.getElementById('profileToast');
            if (toast) {
                console.log("Toast element found, showing now...");
                toast.classList.add('show');
                // Fallback for display if class is not enough
                toast.style.display = 'flex'; 

                setTimeout(() => {
                    toast.classList.remove('show');
                    toast.style.display = 'none';
                }, 3000); 
            } else {
                console.error("Profile toast element not found!");
            }

            profileForm.querySelectorAll('.profile-input').forEach(input => {
                input.readOnly = true;
            });
            profileForm.querySelectorAll('.profile-change-btn').forEach(btn => {
                btn.style.display = 'block';
            });
        });
    }

    window.hideToast = function(toastId) {
        const toast = document.getElementById(toastId);
        if (toast) {
            toast.classList.remove('show');
            toast.style.display = 'none';
        }
    };
});